---
name: flyton
description: "Flyton is a Python-on-the-fly web development methodology using Apache2 CGI, MySQL, and server-rendered HTML on AWS EC2. Use this skill whenever writing any Python web page, API, database access, session management, HTML generation, or JavaScript for a Flyton project. Triggers on any mention of rpage, p4web, cgi-bin, flyton, kiccard, kicbutton, find_in_sql, sql_order, insert_to_sql, ses table, gen table, db_ files, or any request to build a web page or API in this stack. Always use this skill before writing any Python, SQL, JS, or HTML for a Flyton project, even for small changes."
---

# Flyton Development Rules

## Stack
- Apache2 + CGI on Ubuntu EC2 (AWS)
- CloudFront + Route53 for HTTPS/domain
- MySQL database
- Python generates HTML server-side (like PHP)
- AWS Cloud9 as IDE on dev server

## URL Structure
```
/cgi-bin/p?app=start&r=xxx&ses=TOKEN&rpage=dashboard
```
- `ses=` — session token, present on ALL pages - get it after good login
- `rpage=` — current page, maps to `rpage.py`

## Core Flow
`/cgi-bin/p` → `p4web.py` → `/client/app/start.py` → `header.py` + `body.py` + `footer.py`  
`body.py` calls `dashboard.py` when `rpage=dashboard`

## Directory Structure
```
/client/admin
/client/weba
/client/pages            -static pages open to web
/client/pages/lib        ← CSS/JS files go here (assume /lib/ maps here)
/client/pages/files
/client/pages/im
/server/cgi-bin
/server/apis/api         ← api_xxx.py files
/server/apis/tools
/server/apis/tools/cron
```

---

## Database Rules

### Table Structure (all tables follow this)
| Field | Type | Notes |
|-------|------|-------|
| id | int autoincrement | starts at 4-5 digits (e.g. 1000, 30000) |
| name | text | |
| other fields | — | only if ALL records need it |
| is_active | tinyint(1) | 1=active (default), 0=inactive. NEVER delete rows |
| created_at | timestamp | auto |
| updated_at | timestamp | auto |
| data | json | dynamic/extra fields go here |

- `ses` table: `id` is varchar (token string), not int
- All conditions: `0`=false, `1`=true — never use Python `True`/`False` or JS `true`/`false`
- Never write raw SQL — use the utility functions only

### Core SQL Functions
```python
from tools.sql import *   # always import with *

# Read small tables (returns full list)
w = find_in_sql({'table': 'cust', 'fld': 'id', 'val': cust_id,
                 'what': 'username,LastName,FirstName', 'all': 1})
if type(w) is bool:
    return "err"

# Read large tables (yields rows one by one)
id = ""
for obj in sql_order({'table': 'users', 'id': id}):
    id = obj["id"]
    # process obj...
# sql_order params: table, id, where

# Add new record
insert_to_sql({'table': 'cust', 'set':{"name":"John"})
# Update record:
insert_to_sql({'table': 'cust', 'id': cust_id, 'data': {...}})
# Update or Insert data record :
add_to_data('cust',cust_id, {"key":"value"}})
# get Data record
data = get_data('cust',cust_id)
```

### db_ Files
Each table gets its own `db_tablename.py` with these functions under /tools/ :
- `tablename_list()` — list records
- `tablename_get()` — get single record  
- `tablename_chk()` — validate + clean input before save
- `tablename_add()` — insert new record

### gen Table — System Constants
```python
from tools.sql import *
gen = gen_data()
# gen["roles"]["data"]  → roles dict
# gen["year"]["val"]    → year string
```

**Naming conventions in gen:**
- `_type` suffix — small list (e.g. `ast_type`, `os_type`) represent the text options for field "ast_type" in table "ast"
- `_dict` suffix — code→label mapping (e.g. `ast_dict`, `worksp_dict`) 
- `_prov` suffix — providers list (e.g. `email_prov`, `vps_prov`)

```python
# Example gen data
# ast_type  → ["email", "vm", "license", "phone", "persona", "card", "vps", "vpn"]
# ast_dict  → {"is_active": {"0":"pending","1":"free","2":"active","12":"rotating",...}}
# worksp_dict → {"is_active": {"0":"archived","1":"ready","3":"draft","10":"connected"}}
# email_prov → ["gmail","outlook","others"] 
```

---

## Python Code Rules

### Page File Pattern
```python
# dashboard.py
from tools.sql import *
from tools.kiclang import *

def dashboard(data):
    ses = data["ses"]
    if not is_ses_role(ses, "admin"):
        return "no alw"
    h = ""
    h += f"""
        <div id=maindash>
            <h2>{txt("Dashboard")}</h2>
        </div>
    """
    return h
```

- First function name = filename name (`dashboard.py` → `def dashboard(data):`)
- `ses = data["ses"]` — always grab session first
- `h` = main HTML variable
- Use `txt()` for all display text (multilingual support)
- Use `f"""..."""` for multiline HTML — indent nicely
- No conditions inside f-strings — compute before
- No `else` / `elif` — write separate `if` blocks
- Short variable names: `u` for user row, `w` for db result, `c` for item in loop
- No classes — page lifecycle is too short to need them
- No package installs unless absolutely no other choice

### Imports
```python
# Good
from tools.sql import *
from tools.kiclang import *

# Bad
from sql import find_in_sql, insert_to_sql
```

### Role Check
```python
ses = data["ses"]
if not is_ses_role(ses, "admin"):
    return "no alw"
```

---

## Sessions

- Session ID stored in browser `sessionStorage` (not cookies, not localStorage)
- `ses` token appears in every URL and every page's `data["ses"]`
- Save data to session: `add2ses(ses, {"key": "value"})`
- Read session data: `data["s"]["key"]`
- Sessions stored in `ses` table (id = token string)

---

## HTML Generation

```python
h = "<div>"
h += f"""
    <div id=section2>
        <div>{name}</div>
    </div>
"""
return h
```

- No quotes needed on id= unless value has spaces
- Combine multiple lines with `"""`
- Use `print(f"""...""")` for direct output pages

**Combine lines:**
```python
# Good
h += f"""<hr>
         {userslist(data, total)}
         <hr>
"""

# Bad
h += "<hr>"
h += userslist(data, total)
h += "<hr>"
```

---

## UI Components

Bootstrap is always included:
```html
<link href="/lib/bootstrap.min.css" rel="stylesheet">
<script src="/lib/bootstrap.bundle.min.js"></script>
```

### kiccard()
```python
kiccard(
    txt("Manage Assets"),
    "",
    txt("View and manage operational assets"),
    txt("View"),
    ses,
    "assets"
)
```

### kicbutton()
```python
h += f"""
    <span>{kicbutton("save_asset", ses, "Save", "btn btn-primary btn-sm",
          {"ast_id": ast_id, "act": "save"})}</span>
"""
# With form fields: add "use":"field1/field2" to collect input values
```

### Navigation
```python
url = kicnav("assets", ses, {"act": "view", "ast_id": ast_id})
# inject into page:
# <script>let next_url = "{url}";</script>
```

---

## JavaScript Rules

- No `const` or `let` — use `var`
- No `.map()`, `.reduce()` — use plain `for` loops
- No `foo1.foo2.foo3` chains — break into lines
- `function foo() {}` — not `const foo = () => {}`
- All lowercase: `var ast_id`, not `astId`
- Loop vars short: `for(var i=0; i<asts.length; i++) { var a = asts[i]; ... }`
- Find elements by `id`, never by class name
- Events inline: `onclick=save_asset()` — not `addEventListener`
- Static JS → `/lib/filename.js` (never inject `<script>` blocks with static code)
- Use `0` and `1` for booleans, not `true`/`false`

---

## API (Client ↔ Server)

**Client side** (include `kicdev.server.js`):
```html
<script src="/lib/kicdev.server.js"></script>
```
```javascript
var resp = await call_server("api_save_asset", {"ast_id": 123, "name": "VPN-DE"});
if(resp["server"]["allow"]) {
    // success
}
```

**Server side** (`/server/apis/api/api_save_asset.py`):
```python
def api_save_asset(data):
    i = data["post"]["input"]
    ast_id = i["ast_id"]
    nm = i["name"]
    # process...
    api_ok({"ast_id": ast_id})
    # or: api_err("not found")
```

- Method name starts with `api_`
- Each action = its own `api_xxx.py` file
- `api_ok(extra_dict)` — success response
- `api_err("message")` — error response
- Client reads: `resp["server"]["allow"]` and `resp["server"]["your_key"]`

---

## Static Pages
HTML files with no Flyton core — e.g. `/pages/login/index.html` loads directly.

## CSS/JS Files
- Static styles → `/lib/filename.css`
- Static scripts → `/lib/filename.js`
- Never inject `<style>` or `<script>` blocks with static code into HTML body

## Archive
Use the Flyton archive engine for old sessions and logs — keeps tables clean.
